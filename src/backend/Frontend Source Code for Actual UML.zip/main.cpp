#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_opengl3.h"

#include <SDL.h>
#include <SDL_opengl.h>

#include "Frontend/UI.h"
#include "Frontend/Object/Layout.h"

#include "Frontend/Object/Element/BasicElements/Button.h"
#include "Frontend/Object/Element/BasicElements/ImageElement.h"
#include "Frontend/Object/Element/BasicElements/TextLabel.h"

#include "Frontend/Object/Element/DataElements/CheckBox.h"
#include "Frontend/Object/Element/DataElements/Selectable.h"
#include "Frontend/Object/Element/DataElements/SelectList.h"
#include "Frontend/Object/Element/DataElements/Slider.h"
#include "Frontend/Object/Element/DataElements/TextBox.h"

#include "Frontend\ObjectComponents\Color\BaseColor.h"
#include "Frontend\ObjectComponents\Color\ButtonColor.h"
#include "Frontend\ObjectComponents\Color\FrameColor.h"
#include "Frontend\ObjectComponents\Color\GrabColor.h"
#include "Frontend\ObjectComponents\Color\HeaderColor.h"
#include "Frontend\ObjectComponents\Color\WindowBaseColor.h"



int main(int argc, char* argv[])
{
    // Setup SDL
    SDL_Init(SDL_INIT_VIDEO);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, 0);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION,3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,0);

    // Create window
    SDL_Window* window = SDL_CreateWindow(
        "My ImGui App",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        1280,
        720,
        SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE
    );

    SDL_GLContext gl_context = SDL_GL_CreateContext(window);
    SDL_GL_MakeCurrent(window, gl_context);

    // Setup ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui_ImplSDL2_InitForOpenGL(window,gl_context);
    ImGui_ImplOpenGL3_Init("#version 130");

    ///UI

    
    HorizontalLayout* root = new HorizontalLayout(
        Transformation2({100, 100}, {300, 200}),
        WindowBaseColor(),
        "RootLayout",
        true
    );

    SimpleTextLabel* label = new SimpleTextLabel(
        Transformation2({0, 0}, {100, 30}),
        BaseColor(),
        "Hello Text",
        true
    );

    SimpleButton* button = new SimpleButton(
        Transformation2({0, 40}, {120, 40}),
        BaseColor(),
        ButtonColor(),
        "Click Button",
        true
    );

    root->addObj(label);
    root->addObj(button);


    UI ui;
    ui.addUIBlock(new UIBlock(root));

    

    bool running = true;
    while (running)
    {
        // Handle events
        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
            ImGui_ImplSDL2_ProcessEvent(&event);
            if (event.type == SDL_QUIT) {running = false;}
        }

        // Start ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        // Your UI goes here
        ui.UIrender();

        // Render
        ImGui::Render();
        glViewport(0, 0, 1280, 720);
        glClearColor(0.1f,0.1f,0.1f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        SDL_GL_SwapWindow(window);
    }

    // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    SDL_GL_DeleteContext(gl_context);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}