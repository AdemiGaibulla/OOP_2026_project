#ifdef EXPLAIN //혹시 이 파일이 컴파일 안되게 방지해놓은 코드다

//<헤더>
#include "imgui.h" //imgui 핵심 기능
#include "imgui_impl_sdl2.h" //SDL이벤트를 imgui가 이해 가능하게
#include "imgui_impl_opengl3.h"//imgui가 만든 UI를 OpenGL로 화면에 그리게 해준다
/*
ImGUI: 즉시 모드 GUI라이브러리. 버튼, 슬라이더 등을 매 프레임 그려낸다
OpenGL: 3D그래픽 API이다. GPU를 통해 화면에 실제로 픽셀을 랜더링 한다
SDL2: 크로스 플랫폼 가능하게, 운영체제 API를 알아서 호출하여 윈도우 생성, 마우스/키보드 입력, 그래픽(OpenGL)와 오디어 하드웨어에 접근 제어
*/

#include <SDL.h>//SDL이다. 창 생성, 이벤트 처리
#include <SDL_opengl.h>//OpenGL관련 기능을 쓰기 위해 필요

int main(int argc, char* argv[])//imgui식 main func
{
    //<Setup SDL>
    SDL_Init(SDL_INIT_VIDEO);//SDL 초기화, SDL_INIT_VIDEO는 창,화면,그래픽 쓰겠다는 뜻
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, 0);//OpenGL context 설정, 여기선 기본값
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,SDL_GL_CONTEXT_PROFILE_CORE);//OpenGL의 CorePeofile, 현대적인 방식만 쓰는 모드
    
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION,3);//OpenGL버전 3.x
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,0);//OpenGL버전 x.0 --> 3.0ver
    /*OpenGL context: OpenGL API를 사용하여 그래픽을 렌더링하는 데 필요한 모든 상태 정보(State)와 
    리소스(Texture, Buffer, Shader 등)를 저장하는 데이터 구조이자 실행 환경 */

    //<Create window>
    SDL_Window* window = SDL_CreateWindow(//SDL창 class 생성하는 Constructor 아마 heap에 생성하고 pointer반환하는 듯
        "My ImGui App",//창 제목
        SDL_WINDOWPOS_CENTERED,//창의 x위치 화면 중앙
        SDL_WINDOWPOS_CENTERED,//창의 y위치 화면 중앙
        1280,//창 가로 크기
        720,// 창 세로 크기
        SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE//OpenGL 사용할 수 있는 창, 크기조절도 가능
    );

    SDL_GLContext gl_context = SDL_GL_CreateContext(window);//위에서 생성한 창을 OpenGL context로 생성 OpenGL context가 뭔지는 위 참고
    SDL_GL_MakeCurrent(window, gl_context);//현재 OpenGL 작업 대상을 이 context로 설정, 이후 OpenGL명령을 이 창에 적용됨

    //<Setup ImGui>
    IMGUI_CHECKVERSION();//함수 이름대로, 현재 사용 ImGui 헤더와 라이브러리 버전이 맞는지 확인한다
    ImGui::CreateContext();//ImGui내부 상태를 저장할 context를 만든다
    ImGui_ImplSDL2_InitForOpenGL(window,gl_context);//ImGui와 SDL을 연결한다. SDL의 마우스 키보드 이벤트를 imGui로 처리 가능해짐
    ImGui_ImplOpenGL3_Init("#version 130");//ImGio와 OpenGL3 랜더러를 연결한다. ver130은 GLSL 셰이더 버전, OpenGL3와 맞는

    /*
    Execution Context: 프로그램이 특정 작업을 수행하기 위해 기억해야 하는 현재 상태와 환경 정보의 총합. 
    예)Context Switching, 운영체제가 CPU에서 실행 중인 프로세스나 스레드를 변경할 때, 
        기존 작업의 상태(Context)를 저장하고 새로운 작업의 상태를 불러오는 과정을 말합니다.
    
    GLSL(OpenGL Shading Language): OpenGL에서 제공되는, 셰이더 작성을 위해 사용되는 C/C++ 기반 언어. GPU 활용 동작 프로그램에 사용
    */


    bool running = true;
    while (running)//입력처리 -> 화면 갱신 -> 랜더링 반복
    {
        //<Handle events>
        SDL_Event event;//SDL이벤트 클래스 생성
        while (SDL_PollEvent(&event))//SDL이벤트를 하나씩 꺼내서 사용한다, 그 이벤트를 저장할 주소를 전달
        {
            ImGui_ImplSDL2_ProcessEvent(&event);//꺼내온 SDL이벤트를 imGUI에 전달. 그래야 창, 드래그, 입력 타이핑이 작동한다
            if (event.type == SDL_QUIT) {running = false;}//이벤트들 중에서 "창 닫기를 누름"이벤트에 대해 running을 fail해서 while문을 종료
        }

        //<Start ImGui frame>
        //GUI는 매 순간 새 화면을 그린다. 매 반복마다 새로운 프레임을 시작, 그린다
        //순서: 백엔드 새프레임 준비 -> SDL 새프레임 준비 -> ImGui 새프레임 시작
        ImGui_ImplOpenGL3_NewFrame();//백엔드(OpenGL)새프레임
        ImGui_ImplSDL2_NewFrame();//SDL새프레임
        ImGui::NewFrame();//ImGui새프레임

        //<Your UI goes here>
        ImGui::Begin("Hello ImGui!");//ImGui 창 하나를 시작한다
        ImGui::Text("Welcome to Dear ImGui!");//창 제목을 ImGui로 설정한다
        ImGui::End();//ImGui 창을 닫는다. Begin의 짝으로 반드시 같이 쓸 것

        //<Render>
        ImGui::Render();//UI렌더: 지금까지 만든 ImGui UI 정보를 렌더링 가능한 데이터로 변환
        glViewport(0, 0, 1280, 720);//창: OpenGL이 그릴 영역 지정, 창 왼쪽 아래부터 1280x720사용

        glClearColor(0.1f,0.1f,0.1f,1.0f);//이전지우기1: 프레임당 화면을 지울 때 사용할 배경색 선택, RGB와 불투명도
        glClear(GL_COLOR_BUFFER_BIT);//이전지우기2: 이전 프레임 그림을 방금 정한 색으로 깔끔히 지운다

        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());//그리기: ImGui UI 정보를 OpenGL로 그리기
        SDL_GL_SwapWindow(window);//보이기: 그린 결과를 보이기(뒤쪽 버퍼에 먼저 미리 그리고, 앞쪽과 바로 교체)
    }

    //<Cleanup>
    ImGui_ImplOpenGL3_Shutdown();//ImGui OpenGL 연결 해제
    ImGui_ImplSDL2_Shutdown();//ImGui SDL연결 해제
    ImGui::DestroyContext();//ImGui context 삭제

    SDL_GL_DeleteContext(gl_context);//OpenGL Context 삭제
    SDL_DestroyWindow(window);//SDL 창 삭제
    SDL_Quit();//SDL 종료

    /*
    CleanUp은 준비,SetUp 절차의 역순이다

    SDL_Init(SDL_INIT_VIDEO);//SDL 시작
    SDL_Window* window = SDL_CreateWindow(...);//SDL 창 생성
    SDL_GLContext gl_context = SDL_GL_CreateContext(window);// OpenGL context 생성
    
    ImGui::CreateContext();//ImGui context 만듦
    ImGui_ImplSDL2_InitForOpenGL(window,gl_context);//ImGui와 SDL을 연결
    ImGui_ImplOpenGL3_Init("#version 130");//ImGio와 OpenGL3 연결
    */

    return 0;
}

#endif